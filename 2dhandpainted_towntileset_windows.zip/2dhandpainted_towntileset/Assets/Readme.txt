Thank you for purchasing this tileset! I hope you will find it useful.
If you have any questions or comments you are free to email me at: DanielThomasArt@gmail.com
You can find more of my art at www.danielthomasart.com